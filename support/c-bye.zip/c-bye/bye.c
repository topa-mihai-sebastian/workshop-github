#include <stdio.h>

int main(void)
{
	puts("Bye from Unikraft!");

	return 0;
}

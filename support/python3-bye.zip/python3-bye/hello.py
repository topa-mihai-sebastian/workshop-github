import sys


def main():
    print("Bye from Unikraft!")


if __name__ == "__main__":
    sys.exit(main())

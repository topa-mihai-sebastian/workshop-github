#include <iostream>

int main()
{
	std::cout << "Bye from Unikraft!" << std::endl;
	return 0;
}
